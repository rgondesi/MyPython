import helpers 

print(f"__name__ in extras.py: {__name__}")

name = "Keith Thompson"